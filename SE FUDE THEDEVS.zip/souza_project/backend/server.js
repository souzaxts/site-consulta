const express = require('express');
const sqlite3 = require('sqlite3').verbose();
const bcrypt = require('bcrypt');
const cors = require('cors');
const axios = require('axios');
const bodyParser = require('body-parser');
const path = require('path');
const confirmelink = require('./confirmelink');

const app = express();
const PORT = 3000;
const ADMIN_MASTER_KEY = 'malvadeza123'; // Mude esta chave para sua segurança

// Middlewares
app.use(cors());
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: true }));

// Servir arquivos estáticos do diretório pai
app.use(express.static(path.join(__dirname, '..')));

// Inicializar banco de dados SQLite
const db = new sqlite3.Database('./database.db', (err) => {
    if (err) {
        console.error('Erro ao conectar ao banco de dados:', err.message);
    } else {
        console.log('✅ Conectado ao banco de dados SQLite');
    }
});

// Criar tabela de usuários se não existir
db.run(`
    CREATE TABLE IF NOT EXISTS users (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        username TEXT UNIQUE NOT NULL,
        email TEXT UNIQUE NOT NULL,
        password TEXT NOT NULL,
        is_vip INTEGER DEFAULT 0,
        vip_plan TEXT DEFAULT NULL,
        vip_until DATETIME DEFAULT NULL,
        queries_count INTEGER DEFAULT 0,
        queries_limit INTEGER DEFAULT 10,
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP
    )
`, (err) => {
    if (err) {
        console.error('Erro ao criar tabela:', err.message);
    } else {
        console.log('✅ Tabela de usuários pronta');
    }
});

// ==================== ROTAS ====================

// Rota de teste
app.get('/api/test', (req, res) => {
    res.json({ message: 'API funcionando corretamente!' });
});

// Rota de registro
app.post('/api/register', async (req, res) => {
    const { username, email, password, confirmPassword } = req.body;

    // Validações
    if (!username || !email || !password || !confirmPassword) {
        return res.status(400).json({ 
            success: false, 
            message: 'Por favor, preencha todos os campos.' 
        });
    }

    if (password !== confirmPassword) {
        return res.status(400).json({ 
            success: false, 
            message: 'As senhas não coincidem.' 
        });
    }

    if (password.length < 6) {
        return res.status(400).json({ 
            success: false, 
            message: 'A senha deve ter no mínimo 6 caracteres.' 
        });
    }

    // Verificar se usuário ou email já existe
    db.get('SELECT * FROM users WHERE username = ? OR email = ?', [username, email], async (err, row) => {
        if (err) {
            return res.status(500).json({ 
                success: false, 
                message: 'Erro no servidor.' 
            });
        }

        if (row) {
            return res.status(400).json({ 
                success: false, 
                message: 'Usuário ou e-mail já cadastrado.' 
            });
        }

        // Hash da senha
        try {
            const hashedPassword = await bcrypt.hash(password, 10);

            // Inserir usuário no banco
            db.run(
                'INSERT INTO users (username, email, password) VALUES (?, ?, ?)',
                [username, email, hashedPassword],
                function(err) {
                    if (err) {
                        return res.status(500).json({ 
                            success: false, 
                            message: 'Erro ao criar conta.' 
                        });
                    }

                    res.json({ 
                        success: true, 
                        message: 'Conta criada com sucesso!',
                        user: {
                            id: this.lastID,
                            username,
                            email,
                            is_vip: 0,
                            queries_count: 0,
                            queries_limit: 10
                        }
                    });
                }
            );
        } catch (error) {
            res.status(500).json({ 
                success: false, 
                message: 'Erro ao processar senha.' 
            });
        }
    });
});

// Rota de login
app.post('/api/login', (req, res) => {
    const { user, password } = req.body;

    if (!user || !password) {
        return res.status(400).json({ 
            success: false, 
            message: 'Por favor, preencha todos os campos.' 
        });
    }

    // Buscar usuário por username ou email
    db.get('SELECT * FROM users WHERE username = ? OR email = ?', [user, user], async (err, row) => {
        if (err) {
            return res.status(500).json({ 
                success: false, 
                message: 'Erro no servidor.' 
            });
        }

        if (!row) {
            return res.status(401).json({ 
                success: false, 
                message: 'Usuário ou senha incorretos.' 
            });
        }

        // Verificar senha
        try {
            const match = await bcrypt.compare(password, row.password);

            if (match) {
                res.json({ 
                    success: true, 
                    message: 'Login realizado com sucesso!',
                    user: {
                        id: row.id,
                        username: row.username,
                        email: row.email,
                        is_vip: row.is_vip,
                        vip_until: row.vip_until,
                        queries_count: row.queries_count,
                        queries_limit: row.queries_limit
                    }
                });
            } else {
                res.status(401).json({ 
                    success: false, 
                    message: 'Usuário ou senha incorretos.' 
                });
            }
        } catch (error) {
            res.status(500).json({ 
                success: false, 
                message: 'Erro ao verificar senha.' 
            });
        }
    });
});

// Middleware para verificar e expirar VIPs automaticamente
const checkVipStatus = (req, res, next) => {
    const userId = req.body.userId || req.query.userId;
    if (!userId) return next();

    db.get('SELECT is_vip, vip_until FROM users WHERE id = ?', [userId], (err, user) => {
        if (user && user.is_vip === 1 && user.vip_until) {
            const now = new Date();
            const expiration = new Date(user.vip_until);
            
            if (now > expiration) {
                // VIP Expirou
                db.run('UPDATE users SET is_vip = 0, vip_plan = NULL, vip_until = NULL WHERE id = ?', [userId]);
                console.log(`VIP do usuário ${userId} expirou.`);
            }
        }
        next();
    });
};

// Rota para realizar uma consulta (decrementa limite se não for VIP)
app.post('/api/query', checkVipStatus, (req, res) => {
    const { userId } = req.body;

    if (!userId) {
        return res.status(400).json({ success: false, message: 'ID do usuário é necessário.' });
    }

    db.get('SELECT * FROM users WHERE id = ?', [userId], (err, user) => {
        if (err || !user) {
            return res.status(404).json({ success: false, message: 'Usuário não encontrado.' });
        }

        // Verificar se é VIP (após o middleware ter rodado)
        const isVip = user.is_vip === 1;
        
        if (!isVip && user.queries_count >= user.queries_limit) {
            return res.status(403).json({ 
                success: false, 
                message: 'Limite de consultas atingido. Torne-se VIP para consultas ilimitadas!' 
            });
        }

        // Incrementar contador de consultas
        db.run('UPDATE users SET queries_count = queries_count + 1 WHERE id = ?', [userId], (err) => {
            if (err) {
                return res.status(500).json({ success: false, message: 'Erro ao processar consulta.' });
            }
            
            res.json({ 
                success: true, 
                message: 'Consulta realizada com sucesso!',
                queries_count: user.queries_count + 1,
                queries_left: isVip ? 'Ilimitado' : (user.queries_limit - (user.queries_count + 1))
            });
        });
    });
});

// Rota para GERAR o pagamento PIX
app.post('/api/create-payment', async (req, res) => {
    const { userId, planType } = req.body;
    
    const plans = {
        'diario': { days: 1, name: 'Diário', price: 10 },
        'semanal': { days: 7, name: 'Premium (Semanal)', price: 35 },
        'mensal': { days: 30, name: 'Plano VIP/Mensal', price: 80 },
        'max': { days: 90, name: 'Plano VIP MAX', price: 250 }
    };

    const plan = plans[planType];
    if (!plan) return res.status(400).json({ success: false, message: 'Plano inválido.' });

    try {
        // Buscar dados do usuário para o PIX
        db.get('SELECT username FROM users WHERE id = ?', [userId], async (err, user) => {
            if (err || !user) return res.status(404).json({ success: false, message: 'Usuário não encontrado.' });

            // Criar PIX no ConfirmeLink
            const pixData = await confirmelink.criarPix(plan.price, { nome: user.username });
            
            res.json({ 
                success: true, 
                paymentId: pixData.id,
                qrcode: pixData.copiaCola,
                price: plan.price,
                planName: plan.name
            });
        });
    } catch (error) {
        res.status(500).json({ success: false, message: 'Erro ao gerar PIX.' });
    }
});

// Rota para VERIFICAR o pagamento e ATIVAR o VIP
app.post('/api/check-payment', async (req, res) => {
    const { userId, paymentId, planType } = req.body;

    const plans = {
        'diario': { days: 1, name: 'Diário' },
        'semanal': { days: 7, name: 'Premium (Semanal)' },
        'mensal': { days: 30, name: 'Plano VIP/Mensal' },
        'max': { days: 90, name: 'Plano VIP MAX' }
    };

    try {
        const status = await confirmelink.verificarPix(paymentId);
        
        if (status.aprovado) {
            const plan = plans[planType];
            const untilDate = new Date();
            untilDate.setDate(untilDate.getDate() + plan.days);

            db.run(
                'UPDATE users SET is_vip = 1, vip_plan = ?, vip_until = ? WHERE id = ?',
                [plan.name, untilDate.toISOString(), userId],
                function(err) {
                    if (err) return res.status(500).json({ success: false, message: 'Erro ao ativar VIP.' });
                    res.json({ success: true, message: 'Pagamento aprovado! VIP Ativado.', vip_plan: plan.name });
                }
            );
        } else {
            res.json({ success: false, message: 'Pagamento ainda não identificado.', status: status.status });
        }
    } catch (error) {
        res.status(500).json({ success: false, message: 'Erro ao verificar pagamento.' });
    }
});

// Rota para verificar status atual do usuário (útil para atualizar o dashboard)
app.get('/api/user-status/:userId', checkVipStatus, (req, res) => {
    const { userId } = req.params;
    db.get('SELECT id, username, email, is_vip, vip_plan, vip_until, queries_count, queries_limit FROM users WHERE id = ?', [userId], (err, user) => {
        if (err || !user) return res.status(404).json({ success: false, message: 'Usuário não encontrado.' });
        res.json({ success: true, user });
    });
});

// PROXY SEGURO: Faz a consulta externa pelo backend para esconder a API Key do F12
app.post('/api/proxy-query', checkVipStatus, async (req, res) => {
    const { userId, endpoint, dados } = req.body;
    const API_KEY = 'MalvadezaMods2025';
    const BASE_URL = 'http://149.56.18.68:25605/api/consulta/';

    if (!userId || !endpoint || !dados) {
        return res.status(400).json({ success: false, message: 'Dados incompletos.' });
    }

    try {
        // 1. Verificar se o usuário existe e tem limite (O middleware checkVipStatus já rodou)
        db.get('SELECT * FROM users WHERE id = ?', [userId], async (err, user) => {
            if (err || !user) return res.status(404).json({ success: false, message: 'Usuário não encontrado.' });

            const isVip = user.is_vip === 1;
            if (!isVip && user.queries_count >= user.queries_limit) {
                return res.status(403).json({ success: false, message: 'Limite de consultas atingido.' });
            }

            // 2. Fazer a chamada para a API externa (A API KEY FICA AQUI NO BACKEND, SEGURA!)
            try {
                const response = await axios.get(`${BASE_URL}${endpoint}`, {
                    params: { dados, apikey: API_KEY },
                    timeout: 60000 // 60 segundos de limite
                });

                // 3. Incrementar contador se for sucesso
                db.run('UPDATE users SET queries_count = queries_count + 1 WHERE id = ?', [userId]);

                // 4. Retornar apenas o resultado para o frontend
                res.json({ 
                    success: true, 
                    data: response.data,
                    queries_count: user.queries_count + 1,
                    queries_left: isVip ? 'Ilimitado' : (user.queries_limit - (user.queries_count + 1))
                });

            } catch (apiError) {
                console.error('Erro na API Externa:', apiError.message);
                res.status(500).json({ success: false, message: 'Erro ao consultar API externa.' });
            }
        });
    } catch (error) {
        res.status(500).json({ success: false, message: 'Erro interno no servidor.' });
    }
});



// Iniciar servidor
app.listen(PORT, () => {
    console.log(`🚀 Servidor rodando em http://localhost:${PORT}`);
    console.log(`📂 Arquivos estáticos servidos de: ${path.join(__dirname, '..')}`);
});

// Fechar banco de dados ao encerrar
process.on('SIGINT', () => {
    db.close((err) => {
        if (err) {
            console.error(err.message);
        }
        console.log('Banco de dados fechado.');
        process.exit(0);
    });
});
