const axios = require("axios");

/* ===== CONFIG CONFIRMELINK ===== */
const CLIENT_ID = "36bf613f-be34-4035-a4d6-92edc671b087";
const SECRET = "4ed98def-8463-44b9-ac0e-67814c88587c";
const API_BASE_URL = "https://security.confirmelink.website/api";

/* ===== TOKEN ===== */
async function gerarToken() {
  try {
    const { data } = await axios.post(
      `${API_BASE_URL}/token`,
      { clientId: CLIENT_ID, secret: SECRET },
      { headers: { "Content-Type": "application/json" } }
    );
    return data.accessToken;
  } catch (error) {
    console.error("Erro ao gerar token ConfirmeLink:", error.message);
    throw error;
  }
}

/* ===== CRIAR PIX ===== */
async function criarPix(valor, metadata = {}) {
  try {
    const token = await gerarToken();
    const res = await axios.post(
      `${API_BASE_URL}/deposit`,
      {
        value: Number(valor), // em reais
        person: {
          cpf: metadata.cpf || "00000000000",
          name: metadata.nome || "Cliente Malvadeza"
        }
      },
      {
        headers: {
          Authorization: `Bearer ${token}`,
          "Content-Type": "application/json"
        }
      }
    );
    return {
      id: res.data.id,
      copiaCola: res.data.pixCopiaECola,
      valor: valor,
      raw: res.data
    };
  } catch (error) {
    console.error("Erro ao criar PIX ConfirmeLink:", error.message);
    throw error;
  }
}

/* ===== VERIFICAR PIX ===== */
async function verificarPix(id) {
  try {
    const token = await gerarToken();
    const { data } = await axios.post(
      `${API_BASE_URL}/status`,
      { transactionId: id },
      {
        headers: {
          Authorization: `Bearer ${token}`,
          "Content-Type": "application/json"
        }
      }
    );
    
    // Lista de códigos que indicam sucesso/pago
    const statusAprovado = ["aprovado", "approved", "paid", "success", "00", "PAID"];
    const currentStatus = String(data.statusCode || data.status).toUpperCase();
    
    return {
      status: currentStatus,
      aprovado: statusAprovado.includes(currentStatus) || statusAprovado.includes(currentStatus.toLowerCase()),
      raw: data
    };
  } catch (error) {
    console.error("Erro ao verificar PIX ConfirmeLink:", error.message);
    throw error;
  }
}

module.exports = {
  criarPix,
  verificarPix
};
