#!/usr/bin/env python3
import sqlite3
import json

# Conectar ao banco de dados
conn = sqlite3.connect('database.db')
cursor = conn.cursor()

# Obter estrutura da tabela
cursor.execute("SELECT sql FROM sqlite_master WHERE type='table' AND name='users';")
table_structure = cursor.fetchone()

print("=" * 60)
print("ESTRUTURA DA TABELA 'users'")
print("=" * 60)
if table_structure:
    print(table_structure[0])
else:
    print("Tabela não encontrada")

print("\n" + "=" * 60)
print("USUÁRIOS CADASTRADOS")
print("=" * 60)

# Buscar todos os usuários
cursor.execute("SELECT id, username, email, created_at FROM users")
users = cursor.fetchall()

if users:
    for user in users:
        print(f"\nID: {user[0]}")
        print(f"Username: {user[1]}")
        print(f"Email: {user[2]}")
        print(f"Criado em: {user[3]}")
        print("-" * 40)
else:
    print("Nenhum usuário cadastrado")

print("\n" + "=" * 60)
print(f"TOTAL DE USUÁRIOS: {len(users)}")
print("=" * 60)

conn.close()
