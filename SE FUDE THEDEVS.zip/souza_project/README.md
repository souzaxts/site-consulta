# Sistema de Login e Cadastro - Malvadeza Mods

Sistema completo de autenticação com banco de dados SQLite, desenvolvido com Node.js e Express.

## 🚀 Tecnologias Utilizadas

- **Backend**: Node.js + Express
- **Banco de Dados**: SQLite3
- **Segurança**: bcrypt (hash de senhas)
- **Frontend**: HTML5 + CSS3 + JavaScript vanilla

## 📁 Estrutura do Projeto

```
souza_project/
├── backend/
│   ├── server.js          # Servidor Express com todas as rotas
│   ├── database.db        # Banco de dados SQLite (criado automaticamente)
│   ├── package.json       # Dependências do projeto
│   └── node_modules/      # Módulos instalados
├── index.html             # Página de login
├── register.html          # Página de cadastro
├── dashboard.html         # Dashboard (após login)
└── logo.jpg              # Logo do projeto
```

## 🔧 Instalação

### 1. Instalar dependências (já feito)

```bash
cd backend
npm install
```

### 2. Iniciar o servidor

```bash
npm start
```

O servidor estará rodando em: **http://localhost:3000**

## 📋 Funcionalidades

### ✅ Cadastro de Usuários
- Validação de campos obrigatórios
- Verificação de senhas coincidentes
- Senha mínima de 6 caracteres
- Hash de senha com bcrypt
- Verificação de usuário/email duplicado

### ✅ Login de Usuários
- Login com username ou email
- Validação de senha com bcrypt
- Mensagens de erro amigáveis
- Redirecionamento automático após login

### ✅ Banco de Dados
- SQLite (leve, sem necessidade de servidor separado)
- Tabela `users` com campos:
  - `id` (PRIMARY KEY, AUTOINCREMENT)
  - `username` (UNIQUE)
  - `email` (UNIQUE)
  - `password` (hash bcrypt)
  - `created_at` (timestamp)

## 🌐 Endpoints da API

### 1. Teste de conexão
```
GET /api/test
```

### 2. Cadastro
```
POST /api/register
Body: {
  "username": "string",
  "email": "string",
  "password": "string",
  "confirmPassword": "string"
}
```

### 3. Login
```
POST /api/login
Body: {
  "user": "string (username ou email)",
  "password": "string"
}
```

### 4. Listar usuários (para testes)
```
GET /api/users
```

## 🔐 Segurança

- **Senhas criptografadas**: Uso de bcrypt com salt rounds = 10
- **Validação no backend**: Todas as entradas são validadas
- **CORS habilitado**: Permite requisições do frontend
- **Senhas nunca retornadas**: Apenas dados seguros são enviados ao cliente

## 📱 Como Usar

1. **Inicie o servidor backend**:
   ```bash
   cd backend
   npm start
   ```

2. **Acesse o sistema**:
   - Abra o navegador em: `http://localhost:3000/index.html`
   - Ou abra diretamente os arquivos HTML (certifique-se que o servidor está rodando)

3. **Criar uma conta**:
   - Clique em "Criar nova conta"
   - Preencha todos os campos
   - Clique em "Finalizar Cadastro"

4. **Fazer login**:
   - Use seu username ou email
   - Digite sua senha
   - Clique em "Entrar na conta"

## 🧪 Testando a API

### Usando curl:

**Cadastrar usuário:**
```bash
curl -X POST http://localhost:3000/api/register \
  -H "Content-Type: application/json" \
  -d '{"username":"teste","email":"teste@email.com","password":"123456","confirmPassword":"123456"}'
```

**Fazer login:**
```bash
curl -X POST http://localhost:3000/api/login \
  -H "Content-Type: application/json" \
  -d '{"user":"teste","password":"123456"}'
```

**Listar usuários:**
```bash
curl http://localhost:3000/api/users
```

## 📝 Observações

- O banco de dados `database.db` é criado automaticamente na primeira execução
- Os dados persistem mesmo após reiniciar o servidor
- Para resetar o banco, delete o arquivo `database.db` e reinicie o servidor
- O servidor serve os arquivos HTML estáticos automaticamente

## 🛠️ Melhorias Futuras

- [ ] Sistema de recuperação de senha
- [ ] Tokens JWT para sessões
- [ ] Validação de email (confirmação por link)
- [ ] Perfil de usuário editável
- [ ] Sistema de permissões/roles
- [ ] Rate limiting para prevenir ataques
- [ ] Logs de auditoria

## 📄 Licença

Projeto desenvolvido para fins educacionais.
