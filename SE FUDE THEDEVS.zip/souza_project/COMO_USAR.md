# 🚀 GUIA RÁPIDO - Como Usar o Sistema

## ⚡ Início Rápido (3 passos)

### 1️⃣ Instalar dependências
```bash
cd backend
npm install
```

### 2️⃣ Iniciar o servidor
```bash
npm start
```

### 3️⃣ Acessar o sistema
Abra seu navegador em: **http://localhost:3000/index.html**

---

## 📋 O que foi implementado?

✅ **Banco de dados SQLite** (sem necessidade de MySQL/PostgreSQL)  
✅ **API REST completa** com Node.js + Express  
✅ **Sistema de cadastro** com validações  
✅ **Sistema de login** com autenticação segura  
✅ **Hash de senhas** com bcrypt  
✅ **Interface HTML integrada** (seus arquivos originais atualizados)

---

## 🔐 Funcionalidades de Segurança

- ✅ Senhas criptografadas com bcrypt
- ✅ Validação de campos no backend
- ✅ Proteção contra usuários duplicados
- ✅ Senhas nunca são retornadas pela API
- ✅ Login com username OU email

---

## 🧪 Testando o Sistema

### Opção 1: Usar o navegador
1. Acesse `http://localhost:3000/register.html`
2. Crie uma conta
3. Faça login em `http://localhost:3000/index.html`

### Opção 2: Testar a API diretamente

**Cadastrar usuário:**
```bash
curl -X POST http://localhost:3000/api/register \
  -H "Content-Type: application/json" \
  -d '{"username":"joao","email":"joao@email.com","password":"123456","confirmPassword":"123456"}'
```

**Fazer login:**
```bash
curl -X POST http://localhost:3000/api/login \
  -H "Content-Type: application/json" \
  -d '{"user":"joao","password":"123456"}'
```

**Ver usuários cadastrados:**
```bash
curl http://localhost:3000/api/users
```

---

## 📊 Visualizar o Banco de Dados

Execute o script Python incluído:
```bash
cd backend
python3 view_database.py
```

---

## ❓ Problemas Comuns

### Erro: "Cannot find module 'express'"
**Solução:** Execute `npm install` dentro da pasta `backend/`

### Erro: "Port 3000 already in use"
**Solução:** Encerre o processo na porta 3000:
```bash
# Linux/Mac
lsof -ti:3000 | xargs kill -9

# Windows
netstat -ano | findstr :3000
taskkill /PID [número_do_pid] /F
```

### Erro ao conectar com o servidor
**Solução:** Verifique se o servidor está rodando:
```bash
cd backend
npm start
```

---

## 📁 Arquivos Importantes

- `backend/server.js` - Servidor principal com todas as rotas
- `backend/database.db` - Banco de dados SQLite (criado automaticamente)
- `index.html` - Página de login (atualizada com integração à API)
- `register.html` - Página de cadastro (atualizada com integração à API)
- `dashboard.html` - Dashboard após login

---

## 🎯 Próximos Passos Sugeridos

1. Implementar recuperação de senha
2. Adicionar tokens JWT para sessões
3. Criar sistema de perfil de usuário
4. Adicionar validação de email
5. Implementar logout funcional
6. Adicionar rate limiting

---

## 📞 Estrutura da API

| Método | Endpoint | Descrição |
|--------|----------|-----------|
| GET | `/api/test` | Testar se a API está funcionando |
| POST | `/api/register` | Cadastrar novo usuário |
| POST | `/api/login` | Fazer login |
| GET | `/api/users` | Listar todos os usuários |

---

## ✨ Diferenças do Projeto Original

**ANTES (seu projeto):**
- ❌ Sem backend funcional
- ❌ Sem banco de dados
- ❌ Login/cadastro apenas visual (alert)

**AGORA:**
- ✅ Backend Node.js completo
- ✅ Banco de dados SQLite
- ✅ Login/cadastro funcionais
- ✅ Senhas criptografadas
- ✅ Validações robustas

---

**Desenvolvido com Node.js + Express + SQLite + bcrypt**
